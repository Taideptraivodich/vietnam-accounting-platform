# Integration Worker Dispatch v1.0

## Mission

Assemble the accepted/hotfixed EW outputs into a single runnable baseline under Architecture Freeze v1.0.

## Scope allowed

```text
- Wire freeze-scoped modules together.
- Resolve import/path/package layout issues.
- Align schema names with canonical EW-01 contracts.
- Run migrations in correct order.
- Add integration smoke tests.
- Fix integration-only issues that do not alter frozen architecture.
```

## Scope not allowed

```text
- No architecture redesign.
- No new business features.
- No P1/P2 implementation.
- No FIFO.
- No landed cost.
- No serial/batch.
- No manufacturing.
- No repost valuation tool.
- No direct GL writes from business modules.
```

## Required output

```text
INTEGRATED_BASELINE_BUILD_REPORT.md
MIGRATION_ORDER_REPORT.md
CROSS_MODULE_SMOKE_TEST_RESULT.md
OPEN_ISSUES_BEFORE_FINAL_MERGE.md
FINAL_MERGE_RECOMMENDATION.md
```
