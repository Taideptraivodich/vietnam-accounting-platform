# Merge Decision Record Template v1.0

## Review package

```text
Package reviewed:
Date:
Reviewer:
```

## Test result

```text
Build: PASS / FAIL
Migrations: PASS / FAIL
Smoke tests: PASS / FAIL
Append-only checks: PASS / FAIL
Freeze scope check: PASS / FAIL
```

## Decision

```text
[ ] APPROVE INTEGRATED BASELINE v1.0
[ ] PASS WITH REQUIRED PATCHES
[ ] NEED REVISION
[ ] REJECT
```

## Notes

```text
...
```
