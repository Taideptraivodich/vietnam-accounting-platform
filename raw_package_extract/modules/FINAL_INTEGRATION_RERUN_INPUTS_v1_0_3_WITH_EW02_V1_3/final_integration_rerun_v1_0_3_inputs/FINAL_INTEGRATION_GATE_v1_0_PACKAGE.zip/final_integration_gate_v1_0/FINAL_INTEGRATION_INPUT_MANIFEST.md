# Final Integration Input Manifest v1.0

Use the following packages as input for assembly:

| Component | Package / Status | Merge role |
|---|---|---|
| EW-01 Core Accounting / GL | EW-01_TARGETED_REVISION_ROUND3_HOTFIX_v2_1 | Base schema + GL posting contract |
| EW-02 AR/AP | EW-02_ROUND2_P0_REVISION_v1_2 | AR/AP ledger + allocation, after EW-01 |
| EW-03 Sales / Delivery | EW-03_REVISION_PATCH_v1_2 | Sales + delivery flows, after EW-01/EW-02/EW-06 contract alignment |
| EW-04 Purchase / GRNI | EW-04_ROUND3_HOTFIX_COMPLETE_v1_0 | Purchase + GRNI flows, after EW-01/EW-02/EW-06 contract alignment |
| EW-05 Inventory | EW05_PREP_ONLY_TARGETED_REVISION_PACKAGE | Prep-only; convert only after EW-01 schema is present |
| EW-06 VAT Ledger | EW-06_TARGETED_REVISION_READY | VAT ledger baseline + integration contract |

## Canonical contracts

```text
accounts.id is the physical primary key.
Payload field account_id = accounts.id.
Canonical mapping table = account_mappings.
GRNI subtype = goods_received_not_invoiced.
Core Accounting is the only GL writer.
Business modules compose lines and call core posting service.
```
