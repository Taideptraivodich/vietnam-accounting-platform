# Baseline Acceptance Criteria v1.0

## Baseline can be marked Integration PASS only when

```text
1. All freeze-scoped modules build together.
2. All migrations apply in order on a clean database.
3. Cross-module smoke tests pass.
4. No module writes GL directly except Core Accounting.
5. No posted financial/inventory ledger row is updated or deleted.
6. No P1/P2 feature is introduced.
7. All known blockers from Round 3 are resolved.
```

## Baseline cannot be accepted if

```text
- Any table/enum uses grni instead of goods_received_not_invoiced.
- Any module still references company_account_mappings.
- AR/AP allocation cancellation mutates original allocation row.
- Purchase direct-stock invoice path is missing.
- Inventory valuation is calculated after GL.
- Tax ledger lacks source document/journal entry references.
```
