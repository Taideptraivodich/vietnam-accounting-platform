# Cross-module Smoke Test Plan v1.0

## Required smoke tests

### 1. Core GL post / reverse

```text
Create balanced journal entry
Post via core accounting service
Verify gl_entries append-only
Reverse posted entry
Verify reversal entry inserted, original untouched
```

### 2. AR invoice + receipt allocation

```text
Post sales invoice to 131/511/33311
Verify ar_ap_ledger_entries created
Post customer receipt 111/112 -> 131
Create ar_ap_allocation
Cancel allocation using append-only cancellation event
Verify outstanding derived correctly
```

### 3. Delivery then invoice

```text
Post Delivery Note stock issue to goods sent for sale flow
Verify inventory ledger entries
Post Sales Invoice
Verify revenue/VAT GL
Verify COGS transfer 632 -> 157 when sale confirmed
```

### 4. Purchase receipt before invoice / GRNI

```text
Post Purchase Receipt
Verify Dr Inventory / Cr GRNI
Verify GRNI account subtype goods_received_not_invoiced
Post Purchase Invoice against receipt
Verify Dr GRNI + Dr VAT Input / Cr 331
Verify AP ledger created
```

### 5. Purchase invoice updates stock directly

```text
Post Purchase Invoice with direct stock update
Verify Dr Inventory + Dr 1331 / Cr 331 or 111/112
If direct cash/bank, verify no AP outstanding
```

### 6. Inventory Moving Average

```text
Opening stock with offset account
Purchase receipt changes moving average
Stock issue uses current moving average valuation
Negative stock blocked by default
stock_balances updated as cache
inventory_ledger_entries remains source of truth
```

### 7. VAT ledger

```text
Sales Invoice creates output VAT tax_ledger_entries
Purchase Invoice creates input VAT tax_ledger_entries
Tax ledger references source document and journal entry
No final official VAT return required in v1.0
```

### 8. Atomic transaction failure

```text
Force failure after subledger preparation but before GL commit
Verify no partial GL/subledger/inventory/tax writes remain
```

## Pass condition

All smoke tests must pass without P1/P2 implementation.
