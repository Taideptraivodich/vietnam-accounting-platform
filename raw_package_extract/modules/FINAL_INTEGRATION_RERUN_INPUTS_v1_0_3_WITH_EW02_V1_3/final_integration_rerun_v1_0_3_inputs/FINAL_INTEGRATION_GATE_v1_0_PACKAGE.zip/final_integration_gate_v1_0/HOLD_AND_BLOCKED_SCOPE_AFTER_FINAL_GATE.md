# Hold and Blocked Scope After Final Gate

## Still blocked after v1.0 baseline

```text
- FIFO implementation
- Repost valuation tool
- Landed cost
- Valuation tax advanced handling
- Price variance / valuation residual automation
- Purchase invoice before receipt
- Fixed asset received but not billed
- Serial/batch
- Manufacturing inventory flow
- Full TT99 COA production seed without Senior acceptance
- Official VAT return filing/reporting
```

## Requires separate decision

Any item above requires a new ERP Decision or Vietnam Accounting Review before Worker implementation.
