# Final Baseline Assembly Sequence v1.0

## Required assembly order

```text
1. Apply EW-01 Core Accounting / GL foundation
2. Apply EW-06 VAT ledger baseline schema/contract
3. Apply EW-02 AR/AP ledger + allocation
4. Apply EW-05 inventory skeleton only after EW-01 schema is available
5. Apply EW-03 Sales / Delivery baseline
6. Apply EW-04 Purchase / GRNI baseline
7. Run cross-module smoke tests
8. Produce integration report for Senior Final Merge Gate
```

## Why this order

EW-01 defines the canonical company/account/GL/posting contract.
EW-06 defines the tax ledger contract consumed by Sales/Purchase.
EW-02 depends on EW-01 GL posting and party/account metadata.
EW-05 depends on EW-01 accounts and posting service, but remains freeze-scoped Moving Average only.
EW-03/EW-04 depend on EW-01, EW-02, EW-05, and EW-06 contracts.

## Do not do

```text
- Do not rename accounts to chart_of_accounts.
- Do not use company_account_mappings.
- Do not allow account_subtype = grni.
- Do not update/delete posted ledger rows.
- Do not implement FIFO, landed cost, serial/batch, manufacturing, repost valuation.
```
