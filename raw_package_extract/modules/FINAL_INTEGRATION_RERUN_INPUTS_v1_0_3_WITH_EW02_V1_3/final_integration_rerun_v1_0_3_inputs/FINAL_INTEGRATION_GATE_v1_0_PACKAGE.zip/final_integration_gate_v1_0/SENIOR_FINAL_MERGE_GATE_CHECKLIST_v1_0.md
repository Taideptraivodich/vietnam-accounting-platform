# Senior Final Merge Gate Checklist v1.0

Senior may approve integrated baseline only if all items pass:

```text
[ ] EW-01 canonical accounts schema present
[ ] accounts.id used as physical PK
[ ] payload account_id maps to accounts.id
[ ] account_mappings used; company_account_mappings absent
[ ] goods_received_not_invoiced used; grni absent
[ ] Core Accounting is only GL writer
[ ] Business modules call core post/reverse contract
[ ] GL append-only enforcement present
[ ] ar_ap_ledger_entries append-only
[ ] ar_ap_allocations append-only cancellation/reversal model
[ ] inventory_ledger_entries append-only
[ ] stock_balances rebuildable cache only
[ ] tax_ledger_entries minimum contract present
[ ] Inventory valuation computed before GL
[ ] Inventory GL derives from stock_value_difference
[ ] GL + AR/AP + inventory + tax commits atomically
[ ] Negative stock blocked by default
[ ] Backdated inventory blocked if later entries exist
[ ] Direct cash/bank purchase invoice creates no AP outstanding
[ ] Opening stock requires offset account
[ ] Inventory adjustment requires reason + offset_account_id
[ ] No FIFO implementation
[ ] No landed cost implementation
[ ] No serial/batch implementation
[ ] No manufacturing implementation
[ ] Smoke tests passed
```
